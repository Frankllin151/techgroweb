<?php
// data.php

$services = [
    'web_design' => [
        'title' => 'Web Design',
        'content' => 'Criação de interfaces visuais atraentes e funcionais, focadas em melhorar a experiência do <span>usuário</span> e maximizar as <span>conversões</span>. Cada projeto é cuidadosamente planejado para garantir um design único e <span>responsivo</span> que se adapta a diferentes dispositivos.'
    ],
    'desenvolvimento_sites' => [
        'title' => 'Desenvolvimento de Sites',
        'content' => 'Criação e configuração de sites otimizados e <span>responsivos</span>, com integração de funcionalidades avançadas para atender às suas necessidades específicas. Nossos sites são projetados para serem <span>rápidos</span>, <span>seguros</span>, e fáceis de gerenciar.'
    ],
    'desenvolvimento_erps' => [
        'title' => 'Desenvolvimento de ERPs',
        'content' => 'Desenvolvimento de sistemas <span>ERP</span> utilizando <span>Laravel</span>, com módulos para controle de <span>vendas</span>, gestão de estoque, <span>emissão de nota fiscal</span> e muito mais. Soluções de gestão empresarial completas, <span>focadas em automatizar processos</span> e melhorar a eficiência operacional do seu negócio.'
    ],
    'desenvolvimento_lojas' => [
        'title' => 'Desenvolvimento de Lojas',
        'content' => 'Configuração e criação de <span>lojas online</span>, incluindo integração com gateways de pagamento e plugins de marketing para maximizar suas <span>vendas</span>. Criamos lojas personalizadas que são fáceis de gerenciar e oferecem uma <span>experiência de compra excepcional</span> aos seus clientes,
        com <span>tema personalizado </span> com <span>WooCommerce </span> 
        '
    ],
    'seo' => [
        'title' => 'SEO',
        'content' => 'Estratégias de <span>SEO</span> sob medida que aumentam a <span>visibilidade online</span>, entregues de acordo com o planejamento para maximizar seu <span>ROI</span>. Nosso foco é garantir que seu site apareça nas primeiras posições dos motores de busca.'
    ]
];
?>