 <!---parceira-->
 <section>
   <div class="container-parceira">
     <div class="title-parceira">
       <h3>Empresas em parceria com Techgroweb</h3>
     </div>
     <div class="content-parceira">
       <div class="item-parceira">
         <h5>T2solucões</h5>
         <p>Especialista em tecnologia e soluções digitais</p>
       </div>
     </div>
   </div>
 </section>
 <!---parceira end-->